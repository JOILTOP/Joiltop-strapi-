# JTP Audio Strapi Backend
This project manages content for JTP Audio.